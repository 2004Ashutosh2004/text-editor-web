const a= "Harry";
const b= "Rohan";
const c= "Aakash";
const d= "Priyanka";
export default c;
export {a};
export {b};
export {d};
